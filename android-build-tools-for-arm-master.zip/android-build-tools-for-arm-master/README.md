android-build-tools-for-arm
===========================

The Android SDK tools does not support building on Linux Arm. This repository will include the build tools aapt, aidl, zipalign for Linux Arm.

Please refer to http://www.timelesssky.com/blog/building-android-sdk-build-tools-aapt-for-debian-arm for the build instruction.

